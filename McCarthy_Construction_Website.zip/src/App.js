import React from "react";
import "./App.css";

export default function McCarthyConstruction() {
  return (
    <div className="bg-black text-white font-sans">
      {/* Header */}
      <header className="flex justify-between items-center p-6 border-b border-yellow-500">
        <div className="flex items-center">
          <img src="/McCarthy-Construction(1).jpg" alt="McCarthy Logo" className="h-12 mr-3" />
          <h1 className="text-2xl font-bold text-yellow-500">McCarthy <span className="text-white">Construction</span></h1>
        </div>
        <nav className="space-x-4">
          <a href="#home" className="hover:text-yellow-500">Home</a>
          <a href="#about" className="hover:text-yellow-500">About</a>
          <a href="#services" className="hover:text-yellow-500">Services</a>
          <a href="#projects" className="hover:text-yellow-500">Projects</a>
          <a href="#contact" className="hover:text-yellow-500">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section id="home" className="text-center py-20 px-4 bg-[url('/hero-africa.jpg')] bg-cover bg-center">
        <h2 className="text-4xl font-bold mb-4 text-yellow-500">Building a Concrete Nation</h2>
        <p className="text-lg mb-6">Your trusted construction partner in Africa</p>
        <button className="bg-yellow-500 text-black px-6 py-2 font-bold rounded hover:bg-yellow-600">Explore Projects</button>
      </section>

      {/* About */}
      <section id="about" className="px-6 py-16 bg-gray-900">
        <h3 className="text-3xl font-bold text-yellow-500 mb-4">About McCarthy Construction</h3>
        <p className="mb-4">
          McCarthy Construction is a proudly African company committed to delivering strong, sustainable, and innovative construction solutions. 
          From urban housing to community infrastructure, we focus on quality, affordability, and excellence.
        </p>
        <h4 className="text-2xl font-semibold text-yellow-400 mt-8 mb-2">Company Profile</h4>
        <ul className="list-disc list-inside space-y-2">
          <li><strong>Overview:</strong> A full-service construction firm headquartered in Malawi.</li>
          <li><strong>Mission:</strong> To build functional, enduring, and inspiring spaces across Africa.</li>
          <li><strong>Vision:</strong> To be the most respected name in construction across the continent.</li>
          <li><strong>Core Values:</strong> Excellence, Integrity, Innovation, and Community Impact.</li>
          <li><strong>Experience:</strong> Over a decade of delivering residential, commercial, and civic projects.</li>
        </ul>
      </section>

      {/* Services */}
      <section id="services" className="px-6 py-16">
        <h3 className="text-3xl font-bold text-yellow-500 mb-4">Our Services</h3>
        <ul className="list-disc list-inside space-y-3 text-lg">
          <li>General Contracting</li>
          <li>Architectural Design (House Plans & City Planning)</li>
          <li>Project Management</li>
          <li>Design-Build Services</li>
          <li>Renovations & Additions</li>
        </ul>
      </section>

      {/* Projects */}
      <section id="projects" className="px-6 py-16">
        <h3 className="text-3xl font-bold text-yellow-500 mb-4">Projects</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <img src="/african-building1.jpg" alt="African School Building" className="rounded shadow-lg" />
          <img src="/modern-african-house.jpg" alt="Modern African House Render" className="rounded shadow-lg" />
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="px-6 py-16 bg-gray-900">
        <h3 className="text-3xl font-bold text-yellow-500 mb-4">Contact Us</h3>
        <p className="mb-2">Phone: +265 993 05 96 30</p>
        <p>Email: <a href="mailto:mccarthyconstruction.africa" className="text-yellow-500">mccarthyconstruction.africa</a></p>
      </section>

      {/* Footer */}
      <footer className="text-center text-gray-400 py-6 border-t border-gray-700">
        &copy; 2025 McCarthy Construction. All rights reserved.
      </footer>
    </div>
  );
}
